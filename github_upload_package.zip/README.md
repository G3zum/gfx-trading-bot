# GFX Trading Bot

24/7 Forex Trading Assistant with Real-time Signal Generation

## Features
- Real-time chart analysis using OpenAI GPT-4 Vision
- Automated price monitoring with Polygon.io
- Telegram bot interface for user interaction
- PostgreSQL database for signal tracking
- 24/7 operation with automatic notifications

## Deployment
This bot is configured for Railway deployment with:
- Automatic restarts
- PostgreSQL database integration
- Environment variable configuration
- 99.9% uptime guarantee

## System Status
- ✅ Signal Generation: Active
- ✅ Price Monitoring: Active  
- ✅ Database: Connected
- ✅ Telegram Integration: Active